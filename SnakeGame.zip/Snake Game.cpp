﻿#include<stdlib.h>
#include"header.h"
#include<mmsystem.h>

#pragma comment(lib, "winmm.lib")

enum direction 
{Up,Down,Right,Left};

struct Position
{
	int ri, ci;
};
struct Snake
{
	Position* spos;
	int size;
	direction dir;
	string pl_name;
	int lkey, rkey, ukey, dkey;
};
struct food
{
	Position* fpos;
	bool isValid;
};

void init(Snake* &s, food& f, int rows, int cols, string * Pnames, int players)
{
	s[0].spos = new Position[3];
	s[0].spos[0].ri = rows / 2;
	s[0].spos[0].ci = cols / 2;

	s[0].spos[1].ri = rows / 2;
	s[0].spos[1].ci = cols / 2 - 1;

	s[0].spos[2].ri = rows / 2;
	s[0].spos[2].ci = cols / 2 - 2;
	s[0].lkey = 75, s[0].rkey = 77, s[0].ukey = 72, s[0].dkey = 80;

	if (players > 1)
	{
		s[1].spos = new Position[3];
		s[1].spos[0].ri = rows / 2-4;
		s[1].spos[0].ci = cols / 2;

		s[1].spos[1].ri = rows / 2-4;
		s[1].spos[1].ci = cols / 2 - 1;

		s[1].spos[2].ri = rows / 2-4;
		s[1].spos[2].ci = cols / 2 - 2;
		s[1].lkey = 97 , s[1].rkey = 100, s[1].ukey = 119, s[1].dkey = 115;
	}
	if (players > 2)
	{
		s[2].spos = new Position[3];
		s[2].spos[0].ri = rows / 2+4;
		s[2].spos[0].ci = cols / 2;

		s[2].spos[1].ri = rows / 2+4;
		s[2].spos[1].ci = cols / 2 - 1;

		s[2].spos[2].ri = rows / 2+4;
		s[2].spos[2].ci = cols / 2 - 2;
		s[2].lkey = 106, s[2].rkey = 108, s[2].ukey = 105, s[2].dkey = 107;
	}
	if (players > 3)
	{
		s[3].spos = new Position[3];
		s[3].spos[0].ri = rows / 2-7;
		s[3].spos[0].ci = cols / 2;

		s[3].spos[1].ri = rows / 2-7;
		s[3].spos[1].ci = cols / 2 - 1;

		s[3].spos[2].ri = rows / 2-7;
		s[3].spos[2].ci = cols / 2 - 2;
		s[3].lkey = 52, s[3].rkey = 54, s[3].ukey = 56, s[3].dkey = 50;
	}

	for (int i = 0; i < players; i++)
	{
		s[i].size = 3;
		s[i].dir = Right;
	}
	
	f.fpos = new Position;
	f.fpos->ri = rows / 2;
	f.fpos->ci = cols / 2 + 5;

	for (int i = 0; i < players; i++)
	{
		cout << "Enter Player " << i+1 << " name" << endl;
		cin >> Pnames[i];
	}
	
}
void setdirection(Snake* &s, char key, int players)
{
	for (int i = 0; i < players; i++)
	{
		if (key == s[i].lkey)
		{
			if (s[i].dir != Right)
				s[i].dir = Left;
		}
		else if (key == s[i].rkey)
		{
			if (s[i].dir != Left)
				s[i].dir = Right;
		}
		else if (key == s[i].ukey)
		{
			if (s[i].dir != Down)
				s[i].dir = Up;
		}
		else if (key == s[i].dkey)
		{
			if (s[i].dir != Up)
				s[i].dir = Down;
		}
	}
	
}
void snakeDisplay(Snake*& s, int players, int* sded, int dedind, char sym = -37)
{
	bool ded = false;
	for (int j = 0; j < players; j++)
	{
		ded = false;
		for (int k = 0; k < dedind; k++)
		{
			if (sded[k] == j)
				ded = true;
		}
		if (ded == true)
			continue;
		
		SetClr(j+1);
		gotoRowCol(s[j].spos[0].ri, s[j].spos[0].ci);
		cout << char(58);

		for (int i = 1; i < s[j].size; i++)
		{
			gotoRowCol(s[j].spos[i].ri, s[j].spos[i].ci);
			cout << sym;
		}
	}
	SetClr(7);
}
void snakeMovement(Snake* & s, int rows, int cols,int players, int* sded, int dedind)
{
	bool ded = false;
	for (int i = 0; i < players; i++)
	{
		ded = false;
		for (int k = 0; k < dedind; k++)
		{
			if (sded[k] == i)
				ded = true;
		}
		if (ded == true)
			continue;
		for (int j = s[i].size - 1; j >= 1; j--)
		{
			s[i].spos[j] = s[i].spos[j - 1];
		}
		switch (s[i].dir)
		{
		case Left:
			s[i].spos[0].ci--;
			if (s[i].spos[0].ci == -1)
			{
				s[i].spos[0].ci = cols - 1;
			}
			break;
		case Right:
			s[i].spos[0].ci++;
			if (s[i].spos[0].ci == cols)
			{
				s[i].spos[0].ci = 0;
			}
			break;
		case Up:
			s[i].spos[0].ri--;
			if (s[i].spos[0].ri == -1)
			{
				s[i].spos[0].ri = rows - 1;
			}
			break;
		case Down:
			s[i].spos[0].ri++;
			if (s[i].spos[0].ri == rows)
			{
				s[i].spos[0].ri = 0;
			}
			break;
		}
	}
}
bool isFood_Eaten(Snake* &s, food f, int players,int &index)
{
	for (int i = 0; i < players; i++)
	{
		if (s[i].spos[0].ri == f.fpos->ri && s[i].spos[0].ci == f.fpos->ci)
		{
			index = i;
			return true;
		}
	}
	return false;
}
bool isValid(Snake* &s, Position fpos,int players)
{
	for (int j = 0; j < players; j++)
	{
		for (int i = 0; i < s[j].size; i++)
		{
			if (s[j].spos[i].ri == fpos.ri && s[j].spos[i].ci == fpos.ci)
				return false;
		}
	}
	return true;
}
void foodGeneration(Snake* &s, food& f, int rows, int cols, int players)
{
	do {
		f.fpos->ri = rand() % rows;
		f.fpos->ci = rand() % cols;
	} while (!isValid(s, *f.fpos, players));
}
void displayFood(food f)
{
	gotoRowCol(f.fpos->ri, f.fpos->ci);
	cout << char(248);
}
void growSnake(Snake& s)
{
	Position* newsnake= new Position[s.size + 1];
	for (int i = 0; i < s.size; i++)
	{
		newsnake[i] = s.spos[i];
	}
	newsnake[s.size] = s.spos[s.size - 1];
	s.size++;
	delete[]s.spos;
	s.spos = newsnake;
}
bool isSnake_ded(Snake* &s,int players, int* &sded,int& dedind)
{
	bool ded = false;
	for (int j = 0; j < players; j++)
	{
		ded = false;
		for (int k = 0; k < dedind; k++)
		{
			if (sded[k] == j)
				ded = true;
		}
		if (ded == true)
			continue;
		for (int i = 1; i < s[j].size; i++)
		{	
			if (s[j].spos[i].ri == s[j].spos[0].ri && s[j].spos[i].ci == s[j].spos[0].ci)
			{
				sded[dedind] = j;
				dedind++;
				if (dedind == players)
					return true;
				break;
			}
		}
	}
	if (dedind != players)
		return false;
}
void displayScore(int* score, int rows, int cols,int players, int ind)
{
	score[ind]++;
	gotoRowCol(rows + 1, 0);
	cout <<  "P1 Score : " << score[0];
	if (players > 1)
	{
		gotoRowCol(rows + 1, cols / 2 - 15);
		cout << "P2 Score : " << score[1];
	}
	if (players > 2)
	{
		gotoRowCol(rows + 1, cols / 2 + 15);
		cout << "P3 Score : " << score[2];
	}
	if (players > 3)
	{
		gotoRowCol(rows + 1, cols - 15);
		cout << "P4 Score : " << score[3];
	}
		
}

int main1(int players)
{
	srand(time(0));
	int* sded = new int[players];
	for (int i = 0; i < players; i++)
	{
		sded[i] = -1;
	}
	int rows = 39, cols = 134, dedind = 0;
	int* score = new int[players] {};
	char keyreceiver;
	Snake* s = new Snake[players];
	food f;
	string* Pnames = new string[players]{};
	int i;
	init(s, f, rows, cols, Pnames, players);
	system("cls");
	snakeDisplay(s, players, sded, dedind);
	displayFood(f);
	do
	{
		if (_kbhit())
		{
			keyreceiver = _getch();
			if (keyreceiver == -32)
			{
				keyreceiver = _getch();
				setdirection(s, keyreceiver, players);
			}
			else
			{
				setdirection(s, keyreceiver, players);
			}
		}
		snakeDisplay(s, players, sded, dedind);
		Sleep(100);
		snakeDisplay(s, players, sded, dedind, ' ');
		snakeMovement(s, rows, cols, players, sded, dedind);
		if (isFood_Eaten(s, f, players, i))
		{
			snakeDisplay(s, players, sded, dedind);
			Beep(1000, 30);
			snakeDisplay(s, players, sded, dedind, ' ');
			
			displayScore(score, rows, cols, players, i);
			foodGeneration(s, f, rows, cols, players);
			displayFood(f);
			growSnake(s[i]);
		}
	} while (!isSnake_ded(s, players, sded, dedind));
	system("CLS");
	Sleep(1000);
	cout << "RIP! Snakey.. " << endl;
	cout << Pnames[0] << " => Score : " << score[0] << endl;
	if (players > 1)
		cout << Pnames[1] << " => Score : " << score[1] << endl;
	if (players > 2)
		cout << Pnames[2] << " => Score : " << score[2] << endl;
	if (players > 3)
		cout << Pnames[3] << " => Score : " << score[3] << endl;
	system("pause");

	return 0;
}

void drawBoundary(int rows, int cols)
{
	for (int i = 0; i < cols; i++)
	{
		gotoRowCol(0, i);
		cout << "*";
		gotoRowCol(rows-1, i);
		cout << "*";
	}
	for (int i = 0; i < rows; i++)
	{
		gotoRowCol(i, 0);
		cout << "*";
		gotoRowCol(i, cols - 1);
		cout << "*";
	}
}
bool snakeMovementwBoundary(Snake* &s, int rows, int cols, int players, int* &sded, int &dedind)
{
	bool ded = false;
	for (int j = 0; j < players; j++)
	{
		ded = false;
		for (int k = 0; k < dedind; k++)
		{
			if (sded[k] == j)
				ded = true;
		}
		if (ded == true)
			continue;
		for (int i = s[j].size - 1; i >= 1; i--)
		{
			s[j].spos[i] = s[j].spos[i - 1];
		}
		switch (s[j].dir)
		{
		case Left:
			s[j].spos[0].ci--;
			if (s[j].spos[0].ci == 0)
			{
				sded[dedind] = j;
				dedind++;
			}
			break;
		case Right:
			s[j].spos[0].ci++;
			if (s[j].spos[0].ci == cols - 1)
			{
				sded[dedind] = j;
				dedind++;
			}
			break;
		case Up:
			s[j].spos[0].ri--;
			if (s[j].spos[0].ri == 0)
			{
				sded[dedind] = j;
				dedind++;
			}
			break;
		case Down:
			s[j].spos[0].ri++;
			if (s[j].spos[0].ri == rows - 1)
			{
				sded[dedind] = j;
				dedind++;
			}
			break;
		}
	}
	return true;
}
bool onCoord(Position fpos, int rows, int cols)
{
	if (fpos.ri == 0 || fpos.ri == rows-1 || fpos.ci == 0 || fpos.ci == cols-1)
		return true;

	return false;
}
void foodGenerationwBoundary(Snake* &s, food& f, int rows, int cols, int players)
{
	do {
		f.fpos->ri = rand() % rows;
		f.fpos->ci = rand() % cols;
	} while (!isValid(s, *f.fpos, players) || onCoord(*f.fpos, rows, cols));
}

int main2(int players)
{
	srand(time(0));
	int rows = 39, cols = 134, dedind = 0;
	int* score = new int[players] {};
	int* sded = new int[players];
	for (int i = 0; i < players; i++)
	{
		sded[i] = -1;
	}
	char keyreceiver;
	Snake* s = new Snake[players];
	food f;
	string* Pnames = new string[players]{};
	int i;
	init(s, f, rows, cols, Pnames, players);
	system("cls");
	drawBoundary(rows, cols);
	snakeDisplay(s, players, sded, dedind);
	displayFood(f);
	Sleep(100);
	do
	{
		if (_kbhit())
		{
			keyreceiver = _getch();
			if (keyreceiver == -32)
			{
				keyreceiver = _getch();
				setdirection(s, keyreceiver, players);
			}
			else
			{
				setdirection(s, keyreceiver, players);
			}

		}
		snakeDisplay(s, players, sded, dedind);
		Sleep(100);
		snakeDisplay(s, players, sded, dedind, ' ');
		if (!snakeMovementwBoundary(s, rows, cols, players, sded, dedind))
			break;
		if (isFood_Eaten(s, f, players, i))
		{
			snakeDisplay(s, players, sded, dedind);
			Beep(1000, 30);
			snakeDisplay(s, players, sded, dedind, ' ');

			displayScore(score, rows, cols, players, i);
			foodGenerationwBoundary(s, f, rows, cols, players);
			displayFood(f);
			growSnake(s[i]);
		}
	} while (!isSnake_ded(s, players, sded, dedind));
	system("CLS");
	Sleep(1000);
	cout << "RIP! Snakey.. " << endl;
	cout << Pnames[0] << " => Score : " << score[0] << endl;
	if (players > 1)
		cout << Pnames[1] << " => Score : " << score[1] << endl;
	if (players > 2)
		cout << Pnames[2] << " => Score : " << score[2] << endl;
	if (players > 3)
		cout << Pnames[3] << " => Score : " << score[3] << endl;
	system("pause");
	return 0;
}

int main()
{
	int key, players, stage;
	int rows = 39, cols = 134;
	gotoRowCol(rows / 2, cols / 2-5);
	PlaySound(TEXT("lofi-music.wav"), NULL, SND_FILENAME | SND_ASYNC | SND_LOOP);
	cout << "Snake Game"<<endl;
	Sleep(1000);
	system("pause");
	while (true)
	{
		system("cls");
		gotoRowCol(0, 0);
		cout << "Choose Mode : \n";
		cout << "1. Single Player ";
		cout << "2. Multi Player ";
		cout << "0. Exit"<<endl;
		cin >> key;
		switch (key)
		{
		case 0:
			return 0;
			break;
		case 1:
			cout << "Choose Stage: \n";
			cout << "1. Borderless ";
			cout << "2. Boundaries ";
			cout << "0. Return to Type Selection "<<endl;
			cin >> stage;
			switch (stage)
			{
				case 1:
					system("cls");
					main1(1);
					break;
				case 2:
					system("cls");
					main2(1);
					break;
				case 0:
					break;
				default:
					break;
			}
			break;
		case 2:
			do {
				cout << "Choose Number of Players: " << endl;
				cout << "2. 2 players "<<endl;
				cout << "3. 3 players "<<endl;
				cout << "4. 4 players "<<endl;
				cin >> players;
			} while (players < 1 || players > 4);
			
			cout << "Choose Stage: \n";
			cout << "1. Borderless ";
			cout << "2. Boundaries ";
			cout << "0. Return to Type Selection "<<endl;
			cin >> stage;
			switch (stage)
			{
			case 1:
				system("cls");
				main1(players);
				break;
			case 2:
				system("cls");
				main2(players);
				break;
			case 0:
				break;
			default:
				break;
			}
			break;
		default:
			break;
		}
	}
	return 0;
}